(() => {
  const overlay = document.querySelector("#overlay");
  const dialog = overlay.querySelector(".dialog");
  const title = overlay.querySelector("#dialog-title");
  const text = overlay.querySelector("#dialog-text");
  const icon = overlay.querySelector(".bigicon");
  const start = overlay.querySelector("#start-link");
  const close = overlay.querySelector(".close");
  let opener = null;

  function openArea(button) {
    opener = button;
    title.textContent = button.dataset.title;
    text.textContent = button.dataset.text;
    icon.textContent = button.dataset.icon;
    start.href = button.dataset.route || "#";
    overlay.hidden = false;
    close.focus();
  }

  function closeArea() {
    overlay.hidden = true;
    opener?.focus();
  }

  document.querySelectorAll(".area").forEach((button) => {
    button.addEventListener("click", () => openArea(button));
  });
  close.addEventListener("click", closeArea);
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeArea();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !overlay.hidden) closeArea();
  });
  start.addEventListener("click", (event) => {
    if (start.getAttribute("href") === "#") {
      event.preventDefault();
      closeArea();
    }
  });
})();

# English Fun — pacote para OpenCode

Este pacote substitui a página `index-city.html` por uma versão estática, responsiva e acessível do novo English Fun.

## Arquivos

- `index-city.html`: página principal.
- `styles.css`: layout, cores, responsividade e animações.
- `script.js`: abertura e fechamento das áreas.
- `assets/`: cenário e personagens.
- `PROMPT-OPENCODE.txt`: instrução pronta para o OpenCode.

## Antes da substituição

1. Faça uma cópia de segurança da página atual e dos arquivos relacionados.
2. Peça ao OpenCode para localizar os links usados atualmente por APRENDER, QUIZ, OUVIR E ESCREVER, CONVERSAÇÃO, MEMÓRIA, REVISAR ERROS e MEU PROGRESSO.
3. Preencha cada atributo `data-route` do novo `index-city.html` com o destino correspondente.
4. Preserve integrações existentes de autenticação, progresso, áudio e analytics.
5. Publique todos os arquivos mantendo a pasta `assets` ao lado de `index-city.html`.

## Verificação

- Testar em computador e celular.
- Testar todos os sete botões.
- Confirmar que nenhum link retorna erro 404.
- Confirmar que os personagens não cobrem placas ou rostos.
- Confirmar que o cenário carrega sem a mira central.
- Confirmar funcionamento das teclas Tab, Enter e Escape.
